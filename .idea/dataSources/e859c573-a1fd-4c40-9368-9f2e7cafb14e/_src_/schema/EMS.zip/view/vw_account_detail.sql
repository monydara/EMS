CREATE VIEW vw_account_detail AS
  SELECT
    (CASE WHEN (`acd`.`item_type` = 'A')
      THEN `aci`.`item_name`
     WHEN (`acd`.`item_type` = 'D')
       THEN `adit`.`item_name`
     WHEN (`acd`.`item_type` = 'T')
       THEN `atr`.`description`
     ELSE NULL END)        AS `item_name`,
    `acd`.`id`             AS `id`,
    `acd`.`account_id`     AS `account_id`,
    `acd`.`item_id`        AS `item_id`,
    `acd`.`item_type`      AS `item_type`,
    `acd`.`item_unit`      AS `item_unit`,
    `acd`.`item_value`     AS `item_value`,
    `acd`.`is_recurring`   AS `is_recurring`,
    `acd`.`recurring_val`  AS `recurring_val`,
    `acd`.`effective_date` AS `effective_date`,
    `acd`.`expired_date`   AS `expired_date`,
    `acd`.`comments`       AS `comments`,
    `acd`.`is_deleted`     AS `is_deleted`,
    `acd`.`status`         AS `status`,
    `acd`.`user_id`        AS `user_id`,
    `acd`.`created_at`     AS `created_at`,
    `acd`.`updated_at`     AS `updated_at`
  FROM ((((`ems`.`acc_account_details` `acd` LEFT JOIN `ems`.`acc_charge_items` `aci`
      ON (((`aci`.`id` = `acd`.`item_id`) AND (`acd`.`item_type` = 'A')))) LEFT JOIN `ems`.`acc_tax_rates` `atr`
      ON (((`atr`.`id` = `acd`.`item_id`) AND (`acd`.`item_type` = 'T')))) LEFT JOIN
    `ems`.`acc_discount_item_details` `adi`
      ON (((`adi`.`id` = `acd`.`item_id`) AND (`acd`.`item_type` = 'D')))) LEFT JOIN `ems`.`acc_discount_items` `adit`
      ON ((`adit`.`id` = `adi`.`acc_discount_item_id`)));
